const { Service } = require('feathers-sequelize');

exports.Company = class Company extends Service {
  
};
